﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataBaseFunctions2
{
    class Program
    {
        static void Main(string[] args)
        {
            ClubMedUI.OpenScreen();
            Console.ReadKey();
        }
    }
}
