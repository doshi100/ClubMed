﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataBaseFunctions2
{
    class ClubMedUI
    {
        static public void OpenScreen()
        {
            Console.WriteLine("CLUB Center!");
            Console.WriteLine("Choose your preferred action :\n" +
                              "Write[1] in order to add a new club\n" +
                              "Write[2] in order to search for a variety of clubs\n" +
                              "Write[3] to print the clubs capacity in a specific date\n");
            int inputAction = int.Parse(Console.ReadLine());
            switch (inputAction)
            {
                case 1:
                    Console.WriteLine("Option 1");
                    break;
                case 2:
                    Console.WriteLine("Option 2");
                    break;
                case 3:
                    Console.WriteLine("Option 3");
                    break;
                default:
                    Console.WriteLine("please choose 1, 2 or 3");
                    break;
            }

        }

        static public void AddClubUI()
        {

        }

    }
}
