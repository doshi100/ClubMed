﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataBaseFunctions2
{
    class ClubMedUI
    {

        static public void UiUtility()
        {
            int option = OpenScreen();
            if (option == 1)
            {
                AddClubUI();
            }
        }
        static public int OpenScreen()
        {
            bool flag = true;
            int option = 0;
            Console.WriteLine("CLUB Center!");
            Console.WriteLine("Choose your preferred action :\n" +
                              "Write[1] in order to add a new club\n" +
                              "Write[2] in order to search for a variety of clubs\n" +
                              "Write[3] to print the clubs capacity in a specific date\n");
            while (flag)
            {
                try
                {
                    int inputAction = int.Parse(Console.ReadLine());
                    switch (inputAction)
                    {
                        case 1:
                            Console.WriteLine("Option 1");
                            flag = false;
                            option = 1;
                            break;
                        case 2:
                            Console.WriteLine("Option 2");
                            flag = false;
                            option = 2;
                            break;
                        case 3:
                            Console.WriteLine("Option 3");
                            flag = false;
                            option = 3;
                            break;
                        default:
                            Console.WriteLine("please choose 1, 2 or 3");
                            flag = true;
                            break;
                    }
                }
                catch(Exception)
                {
                    Console.WriteLine("please choose 1, 2 or 3");
                }
            }
            return option;
        }

        static public void AddClubUI()
        {
            int totalRooms = 0;
            Console.WriteLine("Please enter the club's name: ");
            string name = ClubMedDBAccess.StringInput("oops, an error, please type again");
            Console.WriteLine("Please enter the club's state id(choose 1-11): ");
            int StateID = ClubMedDBAccess.IntInput("the entered state id doesn't exsist");
            Console.WriteLine("Please enter the club's city: ");
            string city = ClubMedDBAccess.StringInput("oops, an error, please type again");
            Console.WriteLine("Please enter the club's street: ");
            string street = ClubMedDBAccess.StringInput("oops, an error, please type again");
            Console.WriteLine("Please enter the club's street number: ");
            int streetNum = ClubMedDBAccess.IntInput("oops, an error, please type again");
            Console.WriteLine("Please choose:\n" +
                " 1: for a ski category\n" +
                "2: for Water Sport category");
            int category = ClubMedDBAccess.IntInput("oops, an error, please type again");
            Console.WriteLine("Please enter the club's rating (rate 1-5): ");
            int rating = ClubMedDBAccess.IntInput("oops, an error, please type again");
            Console.WriteLine("Please enter the club's rooms number: ");
            int NumOfRooms = ClubMedDBAccess.IntInput("oops, an error, please type again");
            int ClubId = ClubMedDBAccess.AddClub(name, StateID, city, street, streetNum, category, rating, NumOfRooms);
            Console.WriteLine("did it work?"); // delete this line later
            while (totalRooms < NumOfRooms)
            {
                Console.WriteLine("Please enter a club's room type: ");
                int type = ClubMedDBAccess.IntInput("oops, an error, please type again");
                Console.WriteLine("Please enter the number of rooms in the club with the same type: ");
                int typeRooms = ClubMedDBAccess.IntInput("oops, an error, please type again");
                totalRooms += typeRooms;
                if (typeRooms+totalRooms > NumOfRooms)
                {
                    totalRooms -= typeRooms;
                    Console.WriteLine("you have exceeded the number of rooms in the club, please choose accordingly\n" +
                        "the number of rooms in the club currently is: {0}",totalRooms);
                    Console.WriteLine("Please enter the number of rooms in the club with the same type: ");
                    int typeRooms = ClubMedDBAccess.IntInput("oops, an error, please type again");
                }
                Console.WriteLine("Please enter the price for this type of room: ");
                double price = ClubMedDBAccess.doubleInput("oops, an error, please type again");
                Console.WriteLine("Please enter the max vistores who can stay in that room: ");
                int MaxVisitores = ClubMedDBAccess.IntInput("oops, an error, please type again");
                ClubMedDBAccess.AddRoomsPerClub(ClubId, typeRooms, MaxVisitores, type, price);
            }

        }

    }
}
