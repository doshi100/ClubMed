﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.Data;

namespace DataBaseFunctions2
{
    class DBHelper
    {
        //Constants
        public const int WRITEDATA_ERROR = -1;
        //
        private OleDbConnection conn; //holds the connection for all operations using OleDB
        private string provider; //holds the provider for the connection
        private string source; //holds the path to the database file
        private bool connOpen; //indicates if the connection is opened
        public DBHelper(string provider, string source)
        {
            this.provider = provider;
            this.source = source;
            this.connOpen = false;
        }

        public bool OpenConnection()
        {
            string connString = String.Format(@"Provider={0};Data Source={1};Persist Security Info=False;", provider, source);
            conn = new OleDbConnection(connString);
            try
            {
                conn.Open();
                connOpen = true;
                return (conn.State == ConnectionState.Open);
            }
            catch (Exception)
            {
                return false;
            }
        }
        //Execute SELECT sql commands and return a reference to an OleDbDataReader
        //if execution fails return
        public OleDbDataReader ReadData(string sql)
        {
            OleDbDataReader reader;
            if (connOpen != true)
            {
                OpenConnection();
            }
            try
            {
                OleDbCommand cmd = new OleDbCommand(sql, conn);
                reader = cmd.ExecuteReader();
            }
            catch (Exception)
            {
                return null;
            }
            return reader;
        }

        //Execute UPDATE or INSERT sql commands and return number of rows
        //return WRITEDATA_ERROR on failure.
        public int WriteData(string sql)
        {
            int RowsAffected = 0;
            if (connOpen != true)
            {
                OpenConnection();
            }
            try
            {
                OleDbCommand command = new OleDbCommand(sql, conn);
                OleDbDataReader reader = command.ExecuteReader();
                if (reader != null)
                {
                    RowsAffected = reader.RecordsAffected;
                }
            }
            catch (Exception)
            {
                return WRITEDATA_ERROR;
            }
            return RowsAffected;
        }

        //This function should be used for inserting a single record into a table in the
        //database with an autonmuber key.the format of the sql must be
        //INSERT INTO <TableName> (Fields...) VALUES (values...)
        //the function return the autonumber key generated for the new record or
        //WRITEDATA_ERROR if fail.
        public int InsertWithAutoNumKey(string sql)
        {
            OpenConnection();
            try
            {

                int newID = WRITEDATA_ERROR;
                OleDbCommand cmd = new OleDbCommand(sql, conn);
                OleDbDataReader rd = cmd.ExecuteReader();
                if (rd != null && rd.RecordsAffected == 1)
                {
                    cmd = new OleDbCommand(@"SELECT @@Identity", conn);
                    rd = cmd.ExecuteReader();
                    while (rd.Read())
                    {
                        newID = (int)rd[0];
                    }
                }
                conn.Close();
                return newID;
            }
            catch (Exception)
            {
                conn.Close();
                return WRITEDATA_ERROR;
            }
        }


        //This function is closing the connection unless it is already
        public void CloseConnection()
        {
            conn = new OleDbConnection(source);
            if (connOpen != false)
            {
                conn.Close();
            }
        }

        private string BuildConnString()
        {
            return String.Format("@Provider ={0}; Data Source = {1}; Persist Security Info = False; ", provider, source);
        }

        //This function reads from the database a data table fully cached in memory using a
        //standard SQL SELECT statement.
        //The function returns the data table or null on failure.
        public DataTable GetDataTable(string sql)
        {
            OpenConnection();
            try
            {
                OleDbCommand cmd = new OleDbCommand(sql);
                DataTable dataT = new DataTable();
                OleDbDataReader rd = cmd.ExecuteReader();
                dataT.Load(rd);
                CloseConnection();
                return dataT;
            }
            catch (Exception)
            {
                CloseConnection();
                return null;
            }
        }


        //This function reads from the database a data set fully cached in memory using an
        //array of standard SQL SELECT statements.
        //The function returns the data set or null on failure. The table names inside the
        //dataset are sql1, sql2,...
        public DataSet GetDataSet(string[] sql)
        {
            OpenConnection();
            try
            {
                OleDbCommand cmd=new OleDbCommand();
                DataSet dataS = new DataSet();
                
                for (int i = 0; i <sql.Length;i++)
                {
                    cmd =new  OleDbCommand(sql[i],conn);
                    OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
                    adapter.Fill(dataS);
                }
               
                
                CloseConnection();
                return dataS;
            }
            catch(Exception)
            {
                return null;
            }

        }


    }
}
