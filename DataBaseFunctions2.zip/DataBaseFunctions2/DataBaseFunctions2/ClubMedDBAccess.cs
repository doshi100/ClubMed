﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.Data;

namespace DataBaseFunctions2
{
    public class ClubMedDBAccess
    {
        const string PROVIDER = @"Microsoft.ACE.OLEDB.12.0"; //Default provider (aceess file)
        const string SOURCE = @"..\..\ClubMedDB@NEW.accdb"; //relative file path
        public static int AddClub(string name, int StateID, string city, string street, int streetNum, int category, int rating, int NumOfRooms)
        {
            DBHelper h = new DBHelper(PROVIDER, SOURCE);

            //Create Command and Reader for the data
            string sql = "INSERT INTO Club (name, StateID , city, street, streetNum, category, Rating, NumOfRooms ) VALUES('" + name + "', '" + StateID + "', '" + StateID + "', '" + city + "', '" + street + "', '" + streetNum + "', '" + category + "', '" + rating + "', '" + NumOfRooms + "')";
            try
            {
                return h.InsertWithAutoNumKey(sql);
            }
            catch (Exception e)
            {
                throw new Exception("Unable to Insert Club", e);

            }
        }
        public static void AddRoomsPerClub(int CId, int numR, int MaxVisitors, int Type, double price)
        {
            DBHelper h = new DBHelper(PROVIDER, SOURCE);
            //Create Command and Reader for the data
            for (int i = 0; i < numR; i++)
            {
                string sql = "INSERT INTO Room(MaxVisitors, Type, price, ClubID ) VALUES('" + MaxVisitors + "', '" + Type + "', '" + price + "', '" + CId; //מה שהפעולה המוסיפה מחזירה + "')";                
            }          
        }

        public static void AddOrder(string Fname, string Lname, int StateID, string city, string street, int streetNum, int Type, double price, int clubID, int WeekID)
        {
            DBHelper h = new DBHelper(PROVIDER, SOURCE);
            string sql = "INSERT INTO Orders(FName, LName, StateID, city, street, streetNum, Type, price, ClubID, WeekID ) VALUES('" + Fname + "','" + Lname + "','" + StateID + "','" + city + "', '" + street + "','" + streetNum + "','" + Type + "','" + price + "','" + clubID + "','" + WeekID + "')";
            h.WriteData(sql);
            h.CloseConnection();
        }

        public static int IntInput(string s)
        {
            if (s == "" || s == null)
            {
                s = "your request was not valid please try again.";
            }
            int input = -1;
            bool flag = true;
            while(flag)
            {
                try
                {
                    input = int.Parse(Console.ReadLine());
                    flag = false;
                }
                catch(Exception) {
                    Console.WriteLine(s);
                }
            }
            return input;
        }

        public static string StringInput(string s)
        {
            if (s == "" || s == null)
            {
                s = "your request was not valid please try again.";
            }
            string input = "";
            bool flag = true;
            while (flag)
            {
                try
                {
                    input = Console.ReadLine();
                    flag = false;
                }
                catch (Exception)
                {
                    Console.WriteLine(s);
                }
            }
            return input;
        }

        public static double doubleInput(string s)
        {
            if (s == "" || s == null)
            {
                s = "your request was not valid please try again.";
            }
            double input = -1;
            bool flag = true;
            while (flag)
            {
                try
                {
                    input = double.Parse(Console.ReadLine());
                    flag = false;
                }
                catch (Exception)
                {
                    Console.WriteLine(s);
                }
            }
            return input;
        }
    }
    //static void SearchClubByCountry(int country)
    //{
    //    string sql = ("SELECT * FROM Club WHERE StateID =" + country);
    //    try
    //    {
    //        //פתיחת חיבור לבסיס הנתונים
    //        string connString = String.Format(@"Provider={0};Data Source={1};Persist Security Info=False;", PROVIDER, SOURCE);
    //        OleDbConnection conn = new OleDbConnection(connString);
    //        conn.Open();

    //        //Create Command and Reader for the data

    //        OleDbCommand cmd = new OleDbCommand(sql, conn);
    //        OleDbDataReader rd = cmd.ExecuteReader();

    //        //Create an empty data table
    //        DataTable dataTable = new DataTable();
    //        if (rd != null)
    //        {
    //            //Populate the reader data into it
    //            dataTable.Load(rd);
    //            //Now connection can be closed and data is still in the data table!
    //            conn.Close();
    //        }

    //        //Print the data from the dataTable
    //        //Loop through rows (act just like an array)
    //        for (int i = 0; i < dataTable.Rows.Count; i++)
    //        {
    //            Console.WriteLine("Record number {0}", i);
    //            //Get the row object
    //            DataRow dr = dataTable.Rows[i];
    //            //Loop through the rows (alternatively, you can get the value of a column directy by its name, for example: dr["Address"]
    //            for (int j = 0; j < dataTable.Columns.Count; j++)
    //            {
    //                DataColumn dc = dataTable.Columns[j];
    //                Console.WriteLine("{0}: {1}", dc.ColumnName, dr[j]);
    //            }
    //        }
    //    }
    //    catch (Exception e)
    //    {
    //        throw new Exception("Unable to search Club", e);

    //    }
    //}
    //static void SearchClubByRoom(int roomType)
    //{
    //    string sql = ("SELECT Club.*, Room.Type FROM Club INNER JOIN Room ON Club.id = Room.ClubID WHERE Room.Type =" + roomType);
    //    try
    //    {
    //        //פתיחת חיבור לבסיס הנתונים
    //        string connString = String.Format(@"Provider={0};Data Source={1};Persist Security Info=False;", PROVIDER, SOURCE);
    //        OleDbConnection conn = new OleDbConnection(connString);
    //        conn.Open();

    //        //Create Command and Reader for the data

    //        OleDbCommand cmd = new OleDbCommand(sql, conn);
    //        OleDbDataReader rd = cmd.ExecuteReader();

    //        //Create an empty data table
    //        DataTable dataTable = new DataTable();
    //        if (rd != null)
    //        {
    //            //Populate the reader data into it
    //            dataTable.Load(rd);
    //            //Now connection can be closed and data is still in the data table!
    //            conn.Close();
    //        }

    //        //Print the data from the dataTable
    //        //Loop through rows (act just like an array)
    //        for (int i = 0; i < dataTable.Rows.Count; i++)
    //        {
    //            Console.WriteLine("Record number {0}", i);
    //            //Get the row object
    //            DataRow dr = dataTable.Rows[i];
    //            //Loop through the rows (alternatively, you can get the value of a column directy by its name, for example: dr["Address"]
    //            for (int j = 0; j < dataTable.Columns.Count; j++)
    //            {
    //                DataColumn dc = dataTable.Columns[j];
    //                Console.WriteLine("{0}: {1}", dc.ColumnName, dr[j]);
    //            }
    //        }
    //    }
    //    catch (Exception e)
    //    {
    //        throw new Exception("Unable to search Club", e);

    //    }
    //}
}
