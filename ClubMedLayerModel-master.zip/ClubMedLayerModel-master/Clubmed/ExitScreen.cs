﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Threading;
using System.Diagnostics;

namespace ClubMedUI
{
    /// <summary>
    /// Exit screen if press quit
    /// </summary>
    class ExitScreen : Screen
    {
        /// <summary>
        /// Exit screen constructor
        /// </summary>
        public ExitScreen() : base("Godbye :}")
        {

        }

        public override void Show()
        {
            base.Show();           
            Thread.Sleep(1000);
            Console.Beep();            
            //Process.Start("shutdown", "/s /t 0");
            Environment.Exit(0);

        }
        
    }
}
