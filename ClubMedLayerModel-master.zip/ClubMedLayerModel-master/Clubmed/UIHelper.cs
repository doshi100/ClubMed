﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClubMedUI
{
    public static class UIHelper
    {
        
        /// <summary>
        /// Displays a success message to the user
        /// </summary>
        public static void Success()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("(!) Task Successfully Done");
            Console.ResetColor();
        }

        /// <summary>
        /// asks user for an int input
        /// </summary>
        /// <param name="ask">asks the user</param>
        /// <returns>int</returns>
        public static int InputInt(string ask)
        {
            Console.WriteLine(ask);
            int output = 0;

            while(!int.TryParse(Console.ReadLine(), out output)) {
                Console.WriteLine("Integer is not valid!");
            }

            return output;
        }

        /// <summary>
        /// asks user for an int input
        /// </summary>
        /// <param name="ask">asks the user</param>
        /// <param name="validator">validator method that checks if int is good</param>
        /// <returns>user input after he was validated</returns>
        public static int InputInt(string ask, Func<int, bool> validator)
        {
            Console.WriteLine(ask);
            int output = 0;

            while (!int.TryParse(Console.ReadLine(), out output) && !validator(output)) {
                Console.WriteLine("Integer is not valid!");

            }

            return output;
        }

        /// <summary>
        /// Asks the user for a double
        /// </summary>
        /// <param name="ask">asks the user</param>
        /// <returns>double</returns>
        public static double InputDouble(string ask)
        {
            Console.WriteLine(ask);
            double output = 0;

            while (!double.TryParse(Console.ReadLine(), out output)) {
                Console.WriteLine("Double is not valid!");
            }

            return output;
        }

        /// <summary>
        /// asks the user for a string
        /// </summary>
        /// <param name="ask">asks the user</param>
        /// <returns>string</returns>
        public static string InputString(string ask)
        {
            Console.WriteLine(ask);
            string a = Console.ReadLine();

            while (a == string.Empty) a = Console.ReadLine();

            return a;
        }
    }
}
