﻿using ClubMedBL;
using System;

namespace ClubMedUI
{
    public class DisplayCustomer : Screen
    {
        /// <summary>
        /// Display Customer menu
        /// </summary>
        public DisplayCustomer() : base("Display Customer Menu")
        {
        }



        /// <summary>
        /// Shows the menu
        /// </summary>
        public override void Show()
        {
            base.Show();

            int id = UIHelper.InputInt("What is the id of the customer");
            Customer customer = new Customer(id);

            FormView view = new FormView("Customer", customer);

            view.Show();


            Console.ReadKey();
        }
    }

}