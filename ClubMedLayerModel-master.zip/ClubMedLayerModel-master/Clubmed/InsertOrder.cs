﻿using System;
using ClubMedBL;


namespace ClubMedUI
{
    public class InsertOrder : Screen
    {
        public InsertOrder() : base("Order Menu")
        {
        }
        

        public override void Show()
        {
            base.Show();

            bool bad = false;
            int resortId;
            int customerID;
            int type;
            int requestedWeek;
            do {
                customerID = UIHelper.InputInt("Would you kindly insert your customer ID");
                TableView tbView = new TableView("List of Resorts", Resort.GetAllResorts());
                tbView.Show();
                resortId = UIHelper.InputInt("Would you kindly enter your Resort's ID");
                Resort resort = new Resort(resortId);

                TableView tbView2 = new TableView("List of Rooms", Room.GetRoomByResortID(resortId));               
                tbView2.Show();
                type = UIHelper.InputInt("Would you kindly insert your room type's ID sir");
                
                requestedWeek = UIHelper.InputInt("Would you kindly fill in your desired week sir", a => a < 52 && a > 0);
                if (!resort.IsRoomAvailable(type, requestedWeek)) {
                    bad = true;
                    Console.WriteLine("Sorry master, There is no available room of that type. Please try again :}");
                } else
                {
                    bad = false;
                }
            } while (bad);

            Order order = new Order(customerID, requestedWeek, type, resortId);
            UIHelper.Success(); 
            FormView view = new FormView("Here's your order", order);
            view.Show();

            Console.ReadKey();
        }
    }
}
 