﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Threading.Tasks;

namespace ClubMedDAL
{
    public class DBResort
    {
        /// <summary>
        /// Get Resort by ID 
        /// </summary>
        /// <param name="resortId">Resort ID</param>
        /// <returns>Date Row of resort</returns>
        public static DataRow GetResort(int resortId)
        {
            DBHelper helper = new DBHelper(Constants.PROVIDER, Constants.PATH);

            if (!helper.OpenConnection()) throw new ConnectionException();
            string sql = $"SELECT * FROM Resort WHERE ID = " + resortId;
       
            DataTable tb = helper.GetDataTable(sql);
            helper.CloseConnection();
            if (tb.Rows.Count == 0) return null;
            return tb.Rows[0];
        }

        public static DataTable GetAllResorts()
        {
            DBHelper helper = new DBHelper(Constants.PROVIDER, Constants.PATH);

            if (!helper.OpenConnection()) throw new ConnectionException();
            string sql = $"SELECT * FROM Resort";

            DataTable tb = helper.GetDataTable(sql);
            helper.CloseConnection();
            return tb;
        }

    }
}
