﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace ClubMedDAL
{
    public class DBEmployee
    {
        public DataRow GetEmployee(string username)
        {
            DBHelper helper = new DBHelper(Constants.PROVIDER, Constants.PATH);

            if (!helper.OpenConnection()) throw new ConnectionException();
            string sql = $"SELECT * FROM Employees WHERE username = '" + username + "'";
            DataTable tb = helper.GetDataTable(sql);
            DataRow tr = (DataRow)tb.Rows[0];
            helper.CloseConnection();
            return tr;
        } 
    }
}
