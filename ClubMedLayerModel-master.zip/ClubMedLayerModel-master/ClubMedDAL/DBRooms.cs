﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Threading.Tasks;

namespace ClubMedDAL
{
    public class DBRooms
    {
        /// <summary>
        /// Get Room by iD
        /// </summary>
        /// <param name="RoomsId">Rooms ID</param>
        /// <returns>Date Row of ID</returns>
        public static DataRow GetRoom(int RoomsId)
        {
            DBHelper helper = new DBHelper(Constants.PROVIDER, Constants.PATH);
            
            if (!helper.OpenConnection()) throw new ConnectionException();
            string sql = $"SELECT * FROM Rooms WHERE RoomType = " + RoomsId;

            DataTable tb = helper.GetDataTable(sql);
            helper.CloseConnection();
            if (tb.Rows.Count == 0) return null;
            return tb.Rows[0];
        }

        public static DataTable GetRoomByResortID(int resortID)
        {
            DBHelper helper = new DBHelper(Constants.PROVIDER, Constants.PATH);

            if (!helper.OpenConnection()) throw new ConnectionException();
            string sql = $"SELECT * FROM Rooms WHERE ResortID = " + resortID;

            DataTable tb = helper.GetDataTable(sql);
            helper.CloseConnection();
            if (tb.Rows.Count == 0) return null;
            return tb;
        }

        /// <summary>
        /// Get Number Of Rooms by room type and resort id
        /// </summary>
        /// <param name="roomType">Room Type</param>
        /// <param name="resortID">Resort ID</param>
        /// <returns>The type of the room</returns>
        public static int GetNumberOfRooms(int roomType, int resortID)
        {
            DBHelper helper = new DBHelper(Constants.PROVIDER, Constants.PATH);

            if (!helper.OpenConnection()) throw new ConnectionException();

            string sql = $"SELECT RoomTypeNum FROM Rooms WHERE RoomType = {roomType} AND ResortID = {resortID}";

            DataTable tb = helper.GetDataTable(sql);

            if(tb.Rows.Count == 0)
            {
                throw new SQLException();
            }

            return (int)tb.Rows[0]["RoomTypeNum"];
        }
    }
}
