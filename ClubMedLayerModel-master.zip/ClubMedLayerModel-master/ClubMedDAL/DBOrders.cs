﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;


namespace ClubMedDAL
{
    public class DBOrders
    {
        /// <summary>
        /// Get Orders By Customer
        /// </summary>
        /// <param name="customerId">Customer ID</param>
        /// <returns> Date table of Customer</returns>
        public static DataTable GetOrdersByCustomer(int customerId)
        {
            DBHelper helper = new DBHelper(Constants.PROVIDER, Constants.PATH);

            if (!helper.OpenConnection()) throw new ConnectionException();
            string sql = $"SELECT * FROM Orders WHERE CustomerID = " + customerId;

            DataTable tb = helper.GetDataTable(sql);

            helper.CloseConnection();

            return tb;
        }

        /// <summary>
        /// Get Number Of Orders
        /// </summary>
        /// <param name="resortID">Resort ID</param>
        /// <param name="week">week</param>
        /// <param name="roomType">Room Type</param>
        /// <returns>the number of Order</returns>
        public static int GetNumberOfOrders(int resortID, int week, int roomType)
        {
            DBHelper helper = new DBHelper(Constants.PROVIDER, Constants.PATH);
            if (!helper.OpenConnection()) throw new ConnectionException();

            string sql = $"SELECT * FROM Orders WHERE RequestedWeek = {week} AND RoomType = {roomType} AND ResortID = {resortID}";

            DataTable tb = helper.GetDataTable(sql);

            return tb.Rows.Count;
        }

        /// <summary>
        /// Add Order
        /// </summary>
        /// <param name="customerId">Customer ID</param>
        /// <param name="week">Week</param>
        /// <param name="roomType">Room Type</param>
        /// <param name="price">Price</param>
        /// <param name="resortId">Resort ID</param>
        /// <returns>ID Of order</returns>
        public static int AddOrder(int customerId, int week, int roomType, double price ,int resortId)
        {
            DBHelper helper = new DBHelper(Constants.PROVIDER, Constants.PATH);

            if (!helper.OpenConnection()) throw new ConnectionException();

            string sql = $"INSERT INTO Orders (CustomerID, RequestedWeek, RoomType, OrderPrice, ResortID) VALUES('{customerId}','{week}','{roomType}','{price}','{resortId}')";
            
            int a = helper.InsertWithAutoNumKey(sql);
            helper.CloseConnection();

            if (a == -1) throw new SQLException();

            return a;
        }
        /// <summary>
        /// Get order by id
        /// </summary>
        /// <param name="OrderId">Order ID</param>
        /// <returns>Date Row of Order</returns>
        public static DataRow GetOrder(int OrderId)
        {
            DBHelper helper = new DBHelper(Constants.PROVIDER, Constants.PATH);

            if (!helper.OpenConnection()) throw new ConnectionException();
            string sql = $"SELECT * FROM Orders WHERE ID = " + OrderId;

            DataTable tb = helper.GetDataTable(sql);
            helper.CloseConnection();
            if (tb.Rows.Count == 0) return null;
            return tb.Rows[0];
        }
    }
}
