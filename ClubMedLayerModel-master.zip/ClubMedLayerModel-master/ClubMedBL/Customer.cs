﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClubMedDAL;
using System.Data;

namespace ClubMedBL
{
    public class Customer
    {
        public int ID { get; set; }
        public string FName { get; set; }
        public string LName { get; set; }
        public string Address { get; set; }

        public List<Order> Orders { 
        get {
                List<Order> orders = new List<Order>();
                foreach(DataRow row in DBOrders.GetOrdersByCustomer(ID).Rows)
                {
                    orders.Add(new Order(row));
                }

                return orders;
            }

}
        /// <summary>
        /// Get all customers with a last name
        /// </summary>
        /// <param name="LName">Last name</param>
        /// <returns>list of customers</returns>
        public static List<Customer> GetCustomersByLastName(string LName)
        {
            List<Customer> list = new List<Customer>();

            foreach(DataRow row in DBCustomers.GetCustomersByLastName(LName).Rows)
            {
                list.Add(new Customer(row));
            }

            return list;
        }
        /// <summary>
        /// insert constructor
        /// </summary>
        /// <param name="fname">Frist name</param>
        /// <param name="lname">Last Name</param>
        /// <param name="address">Address</param>
        public Customer(string fname, string lname, string address)
        {
            ID = DBCustomers.InsertCustomer(fname, lname, address);
            this.FName = fname;
            this.LName = lname;
            this.Address = address;
        }
        /// <summary>
        /// constructor from DB
        /// </summary>
        /// <param name="Id"> ID</param>
        public Customer(int Id)
        {
            this.ID = Id;

            DataRow row = DBCustomers.GetCustomersById(Id);

            this.FName = (string)row["FName"];
            this.LName = (string)row["LName"];
            this.Address = (string)row["Address"];
        }
        /// <summary>
        /// constructor from DB
        /// </summary>
        /// <param name="row"> Row of Customer</param>
        public Customer(DataRow row)
        {
            this.ID = (int)row["ID"];
            this.FName = (string)row["FName"];
            this.LName = (string)row["LName"];
            this.Address = (string)row["Address"];
        }

        public override string ToString()
        {
            return $"#{ID} {FName} {LName}";
        }
    }
}
