﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using ClubMedDAL;
namespace ClubMedBL
{
    public class Room
    {
        public int roomType { get; set; }
        public int roomTypeNum { get; set; }
        public int resortId { get; set; }
        public double listPrice { get; set; }



        public Room(DataRow row)
        {
            roomType = (int)row["RoomType"];
            roomTypeNum = (int)row["RoomTypeNum"];
            resortId = (int)row["ResortID"];
            listPrice = (double)row["ListPrice"];          
        }

        public static List<Room> GetRoomByResortID(int resortId)
        {
            DataTable tb = DBRooms.GetRoomByResortID(resortId);
            List<Room> output = new List<Room>();
            foreach (DataRow row in tb.Rows)
            {
                output.Add(new Room(row));
            }
            return output;
        }
    }
}
