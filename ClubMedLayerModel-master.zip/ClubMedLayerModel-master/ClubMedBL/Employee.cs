﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClubMedDAL;
using System.Data;
namespace ClubMedBL
{
    class Employee
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public int Type { get; set; }


        public Employee(string name)
        {
            DataRow dr;
            dr = DBEmployee.GetEmployee(name);
        }
    }
}
