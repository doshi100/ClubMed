﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Text;
using System.Threading.Tasks;
using ClubMedDAL;


namespace ClubMedBL
{
    public class Resort
    {
        public int ID { get; set; }
        public string ResortName { get; set; }
        public int MainActivity { get; set; }
        public int Rating { get; set; }
        public string Address { get; set; }
        public int StartingTime { get; set; }
        public int EndingTime { get; set; }

        /// <summary>
        /// Checks if room is available in this resort
        /// </summary>
        /// <param name="roomType">type of room</param>
        /// <param name="week">week of order</param>
        /// <returns>true if room is available</returns>
        public bool IsRoomAvailable(int roomType, int week)
        {
            return DBRooms.GetNumberOfRooms(roomType, ID) > DBOrders.GetNumberOfOrders(ID, week, roomType);
        }

        /// <summary>
        /// Creates a resort from database by ID
        /// </summary>
        /// <param name="ID">ID of resort</param>
        public Resort(int ID)
        {
            DataRow row = DBResort.GetResort(ID);
            this.ID = ID;
            ResortName = (string)row["ResortName"];
            MainActivity = (int)row["MainActivity"];
            StartingTime = (int) row["StartActivityTime"];
            Address = (string)row["Address"];
            EndingTime = (int)row["EndActivityTime"];
        }
        /// <summary>
        /// Creates a result from existing DataRow
        /// </summary>
        /// <param name="row">the DataRow</param>
        public Resort(DataRow row)
        {
            ID = (int)row["ID"];
            ResortName = (string)row["ResortName"];
            MainActivity = (int)row["MainActivity"];
            StartingTime = (int)row["StartActivityTime"];
            Address = (string)row["Address"];
            EndingTime = (int)row["EndActivityTime"];
        }

        /// <summary>
        /// Returns all resorts
        /// </summary>
        /// <returns>all Resorts</returns>
        public static List<Resort> GetAllResorts()
        {
            DataTable tb = DBResort.GetAllResorts();
            List<Resort> output = new List<Resort>();
            foreach(DataRow row in tb.Rows)
            {
                output.Add(new Resort(row));
            }
            return output;
        }

        
    }
}
