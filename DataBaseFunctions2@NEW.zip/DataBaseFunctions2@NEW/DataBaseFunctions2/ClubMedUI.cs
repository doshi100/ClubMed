﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataBaseFunctions2
{
    class ClubMedUI
    {
        //static bool used = false;

        //***************************
        static public void UiUtility()
        {
                int option = OpenScreen();
                if (option == 1)
                {
                    AddClubUI();
                }
                else if (option == 2)
                {

                }
                else if (option == 3)
                {
                    AddOrderUI();
                }
                else if (option == 4)
                {
                    FinancesUI();
                }
		}
        //*****************************
        static public int OpenScreen()
        {
            bool flag = true;
            int option = 0;
            Console.WriteLine("CLUB Center!");
            Console.WriteLine("Choose your preferred action :\n" +
                              "Write[1] In order to add a new club\n" +
                              "Write[2] In order to search for a variety of clubs\n" +
                              "Write[3] To initiate an order in a club\n" +
                              "write[4] To print the clubs capacity in a specific date");
            while (flag)
            {
                try
                {
                    int inputAction = int.Parse(Console.ReadLine());
                    switch (inputAction)
                    {
                        case 1:
                            Console.WriteLine("Option 1");
                            flag = false;
                            option = 1;
                            break;
                        case 2:
                            Console.WriteLine("Option 2");
                            flag = false;
                            option = 2;
                            break;
                        case 3:
                            Console.WriteLine("Option 3");
                            flag = false;
                            option = 3;
                            break;
                        case 4:
                            Console.WriteLine("Option 4");
                            flag = false;
                            option = 4;
                            break;
                        default:
                            Console.WriteLine("please choose 1, 2 or 3");
                            flag = true;
                            break;
                    }
                }
                catch(Exception)
                {
                    Console.WriteLine("please choose 1, 2 or 3");
                }
            }
            return option;
        }

        static public void AddClubUI() //** my version
        {
            int totalRooms = 0;
            Console.WriteLine("Please enter the club's name: ");
            string name = ClubMedDBAccess.StringInput("oops, an error, please type again");
            Console.WriteLine("Please enter the club's state id(choose 1-11): "); //
            int StateID = ClubMedDBAccess.IntInput("oops, an error, please type again");
            ClubMedDBAccess.IsExsist(StateID, "StateID", "State");
            Console.WriteLine("Please enter the club's city: ");
            string city = ClubMedDBAccess.StringInput("oops, an error, please type again");
            Console.WriteLine("Please enter the club's street: ");
            string street = ClubMedDBAccess.StringInput("oops, an error, please type again");
            Console.WriteLine("Please enter the club's street number: ");
            int streetNum = ClubMedDBAccess.IntInput("oops, an error, please type again");
            Console.WriteLine("Please choose:\n" +
                "1: for a ski category\n" +
                "2: for Water Sport category");
            int category = ClubMedDBAccess.IntInput("oops, an error, please type again");
            Console.WriteLine("Please enter the club's rating (rate 1-5): "); //
            int rating = ClubMedDBAccess.IntInput("oops, an error, please type again");
            ClubMedDBAccess.IsExsist(rating, "Rating", "Club");
            Console.WriteLine("Please enter the club's rooms number: ");
            int NumOfRooms = ClubMedDBAccess.IntInput("oops, an error, please type again");
            int ClubId = ClubMedDBAccess.AddClub(name, StateID, city, street, streetNum, category, rating, NumOfRooms);
            // ******************************
            while (totalRooms < NumOfRooms)
            {
                Console.WriteLine("Please enter a club's room type: "); //
                int type = ClubMedDBAccess.IntInput("oops, an error, please type again");
                ClubMedDBAccess.IsExsist(type, "TypeId", "RoomType");
                Console.WriteLine("Please enter the number of rooms in the club with the same type: ");
                int typeRooms = ClubMedDBAccess.IntInput("oops, an error, please type again");
                totalRooms += typeRooms;
                if (totalRooms > NumOfRooms)
                {
                    while (totalRooms > NumOfRooms) {
                    totalRooms -= typeRooms;
                    Console.WriteLine("you have exceeded the number of rooms in the club, please choose accordingly\n" +
                        "the number of rooms in the club currently is: {0}",totalRooms);
                    Console.WriteLine("Please enter the number of rooms in the club with the same type: ");
                    typeRooms = ClubMedDBAccess.IntInput("oops, an error, please type again");
                    totalRooms += typeRooms;
                    }
                }
                Console.WriteLine("Please enter the price for this type of room: ");
                double price = ClubMedDBAccess.doubleInput("oops, an error, please type again");
                Console.WriteLine("Please enter the max vistores who can stay in that room: ");
                int MaxVisitores = ClubMedDBAccess.IntInput("oops, an error, please type again");
                ClubMedDBAccess.AddRoomsPerClub(totalRooms, MaxVisitores, type, price, ClubId);
                Console.WriteLine("{0} rooms which has the type {1} were succesfully added", typeRooms, type);
                Console.WriteLine("would you like to move back to the menu? write 1 for yes");
                int choice = ClubMedDBAccess.IntInput("oops, an error, please type again");
                if (choice == 1)
                {
                    UiUtility();
                }
            }

        }

		static public void FinancesUI()//******************************
		{
			Console.WriteLine("How Many Club Reports Would You Like To View?");
			int n = ClubMedDBAccess.IntInput("oops, an error, please type again");
			int[] clubID = new int[n];
			for (int i = 0; i < n; i++)
			{
				Console.WriteLine("Enter Your #" + i + " Choice's Club ID:");
				int Cid = ClubMedDBAccess.IntInput("oops, an error, please type again");
                ClubMedDBAccess.IsExsist(Cid, "id", "Club");
				clubID[i] = Cid;
			}

			for (int u = 0; u < clubID.Length; u++)
			{
				ClubMedDBAccess.PrintDataSet(ClubMedDBAccess.Finances(clubID));
			}
            Console.WriteLine("would you like to move back to the menu? write 1 for yes");
            int choice = ClubMedDBAccess.IntInput("oops, an error, please type again");
            if(choice == 1)
            {
                UiUtility();
            }
		}

		static public void AddOrderUI()//***********************************
		{
			Console.WriteLine("Enter Your First Name: ");
			string Fname = ClubMedDBAccess.StringInput("oops, an error, please type again");
			Console.WriteLine("Enter Your Last Name: ");
			string Lname = ClubMedDBAccess.StringInput("oops, an error, please type again");
			Console.WriteLine("Enter Your State ID (CHOOSE 1-11): ");
			int StateID = ClubMedDBAccess.IntInput("the entered state id doesn't exsist");
			Console.WriteLine("Enter Your City: ");
			string city = ClubMedDBAccess.StringInput("oops, an error, please type again");
			Console.WriteLine("Enter Your Street Location: ");
			string street = ClubMedDBAccess.StringInput("oops, an error, please type again");
			Console.WriteLine("Enter Your Street Number: ");
			int streetNum = ClubMedDBAccess.IntInput("oops, an error, please type again");
			Console.WriteLine("Enter Desired Room's ID");
			int RId = ClubMedDBAccess.IntInput("oops, an error, please type again");
            ClubMedDBAccess.IsExsist(RId, "RId", "Room");
            int price = ClubMedDBAccess.GetRoomPrice(RId);
			int Type = ClubMedDBAccess.GetRoomType(RId);
			int ClubID = ClubMedDBAccess.GetRoomClub(RId);
			Console.WriteLine("Please Enter Week ID: ");
			int WeekID = ClubMedDBAccess.IntInput("the entered state id doesn't exsist");
			while (WeekID < 1 || WeekID > 52)
			{
				Console.WriteLine("Please Enter Week ID: ");
				WeekID = ClubMedDBAccess.IntInput("the entered state id doesn't exsist");
			}
			ClubMedDBAccess.AddOrder(Fname, Lname, StateID, city, street, streetNum, Type, price, ClubID, WeekID, RId);
			Console.WriteLine();
			Console.WriteLine("Your Order For the Room" + RId + "in the Club " + ClubMedDBAccess.GetClubName(ClubID) + " has SUCCESSFULLY BEEN ADDED!");
            Console.WriteLine("would you like to move back to the menu? write 1 for yes");
            int choice = ClubMedDBAccess.IntInput("oops, an error, please type again");
            if (choice == 1)
            {
                OpenScreen();
            }
        }

	}
}
