﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.Data;

namespace DataBaseFunctions2
{
    public class ClubMedDBAccess
    {
        const string PROVIDER = @"Microsoft.ACE.OLEDB.12.0"; //Default provider (aceess file)
        const string SOURCE = @"..\..\ClubMedDB@NEW.accdb"; //relative file path
        public static int AddClub(string name, int StateID, string city, string street, int streetNum, int category, int rating, int NumOfRooms)
        {
            DBHelper h = new DBHelper(PROVIDER, SOURCE);

            //Create Command and Reader for the data
            string sql = "INSERT INTO Club (name, StateID , city, street, streetNum, category, Rating, NumOfRooms ) VALUES('" + name + "', '" + StateID +  "', '" + city + "', '" + street + "', '" + streetNum + "', '" + category + "', '" + rating + "', '" + NumOfRooms + "')";
            try
            {
                return h.InsertWithAutoNumKey(sql);
            }
            catch (Exception e)
            {
                throw new Exception("Unable to Insert Club", e);

            }
        }

        public static int GetMaxId(string IdColumn,string table)
        {
            string sql = string.Format($@"SELECT MAX([{IdColumn}] ) FROM [{table}];");
            DBHelper h = new DBHelper(PROVIDER, SOURCE);
            OleDbDataReader rd = h.ReadData(sql);
            int Max = 0;
            while (rd.Read())
            {
                Max = (int)rd[0];
            }
            return Max;
        }

        public static int IsExsist(int input,string IdColumn,string table2)
        {
            if (input > ClubMedDBAccess.GetMaxId(IdColumn, table2))
            {
                Console.WriteLine("Your submission does not exist in the table, please enter it again");
                input = ClubMedDBAccess.IntInput("the entered state id doesn't exsist");
                while (input > ClubMedDBAccess.GetMaxId(IdColumn, table2))
                {
                    Console.WriteLine("Your submission does not exist in the table, please enter it again");
                    input = ClubMedDBAccess.IntInput("the entered state id doesn't exsist");
                }
            }
            return input;
        }
        //public static void AddRoomsPerClub(int CId, int numR, int MaxVisitors, int Type, double price)
        //{
        //    DBHelper h = new DBHelper(PROVIDER, SOURCE);
        //    Create Command and Reader for the data
        //    for (int i = 0; i < numR; i++)
        //        {
        //            string sql = "INSERT INTO Room(MaxVisitors, Type, price, ClubID ) VALUES('" + MaxVisitors + "', '" + Type + "', '" + price + "', '" + CId + "')"; //מה שהפעולה המוסיפה מחזירה + "')";
        //            h.WriteData(sql);
        //        }
        //}

        public static int AddRoomsPerClub(int numR, int MaxVisitors, int Type, double price, int ClubID)
        {
            DBHelper h = new DBHelper(PROVIDER, SOURCE);
            //Create Command and Reader for the data
            int numkey = 0;
            for (int i = 0; i < numR; i++)
            {
                string sql = "INSERT INTO Room(MaxVisitors, Type, price, ClubID ) VALUES('" + MaxVisitors + "', '" + Type + "', '" + price + "', '" + ClubID + "')";
                h.InsertWithAutoNumKey(sql);
                try
                {
                    numkey = h.InsertWithAutoNumKey(sql);
                }
                catch (Exception e)
                {
                    throw new Exception("Unable to Insert Rooms - Per - Club", e);
                }
            }
            return numkey;
        }


		/// <summary>
		/// QUERY 3
		/// </summary>
		/// <param name="RId"></param>
		/// <returns></returns>
		/// 		
		public static int GetRoomPrice(int RId)//
		{
			DBHelper h = new DBHelper(PROVIDER, SOURCE);
			string sql = @"SELECT price FROM Room WHERE RId = " + RId + ";";
			OleDbDataReader rd = h.ReadData(sql);
            int rdV = 0;
            while(rd.Read())
            {
                rdV = (int)rd[0];
            }
            return rdV;
		}
		public static int GetRoomType(int RId)//*******************************
		{
			DBHelper h = new DBHelper(PROVIDER, SOURCE);
			string sql = "SELECT Type FROM Room WHERE RId = " + RId + ";";
			OleDbDataReader rd = h.ReadData(sql);
            int rdV = 0;
            while (rd.Read())
            {
                rdV = (int)rd[0];
            }
            return rdV;
		}
		public static int GetRoomClub(int RId)//*******************************
		{
			DBHelper h = new DBHelper(PROVIDER, SOURCE);
			string sql = "SELECT ClubID FROM Room WHERE RId = " + RId + ";";
			OleDbDataReader rd = h.ReadData(sql);
            int rdV = 0;
            while (rd.Read())
            {
                rdV = (int)rd[0];
            }
            return rdV;
		}
		public static string GetClubName(int ClubID)//******************************
		{
			DBHelper h = new DBHelper(PROVIDER, SOURCE);
			string sql = "SELECT name FROM Club WHERE id = " + ClubID + ";";
			OleDbDataReader rd = h.ReadData(sql);
            string rdV = "";
            while (rd.Read())
            {
                rdV = (string)rd[0];
            }
            return rdV;
        }

		public static void AddOrder(string Fname, string Lname, int StateID, string city, string street, int streetNum, int Type, int price, int ClubID, int WeekID, int RId)//*******************************
		{
			DBHelper h = new DBHelper(PROVIDER, SOURCE);
			string sql = "INSERT INTO Orders(FName, LName, StateID, city, street, streetNum, Type, price, ClubID, WeekID ) VALUES('" + Fname + "', '" + Lname + "', " + StateID + ", '" + city + "', '" + street + "', " + streetNum + ", " + Type + ", " + price + ", " + ClubID + ", " + WeekID + ")";
			//h.WriteData(sql);
			int valueKey = h.InsertWithAutoNumKey(sql);

			string sql2 = "INSERT INTO OrdersPerRoom ( RId, OrderID ) VALUES('" + RId + "', '" + valueKey + "')";

			h.WriteData(sql2);
		}


		/// <summary>
		/// QUERY 4
		/// </summary>
		/// <param name="clubID"></param>

		//דו"ח מלא ALL TOGETHER
		public static DataSet Finances(int[] clubID)
		{
			DBHelper h = new DBHelper(PROVIDER, SOURCE);
			string[] sql0 = new string[2];
			for (int i = 0; i < clubID.Length; i++)
			{
				string sql = "SELECT " + clubID[i] + ", Club.name, COUNT(OrdersPerRoom.RId) FROM ((ClubINNER JOIN Orders ON " + clubID[i] + " = Orders.ClubID) INNER JOIN OrdersPerRoom ON Orders.OrderID = OrdersPerRoom.OrderID) GROUP BY Orders.ClubID, Club.name";
				string sql1 = "SELECT NumOfRooms, ((SELECT COUNT(*) FROM OrdersPerRoom) * 100 / NumOfRooms) WHERE Club.id = " + clubID[i] + " FROM Club GROUP BY NumOfRooms";
				sql0[0] = sql;
				sql0[1] = sql1;
			}
			return h.GetDataSet(sql0); //Loop This twice in UI
		}

		public static void PrintDataSet(DataSet ds)//*********************
		{
			//Console.WriteLine("Tables in '{0}' DataSet.\n", ds.DataSetName);
			foreach (DataTable dt in ds.Tables)
			{
				Console.WriteLine("{0} Table.\n", dt.TableName);
				for (int curCol = 0; curCol < dt.Columns.Count; curCol++)
				{
					Console.Write(dt.Columns[curCol].ColumnName.Trim() + "\t");
				}
				for (int curRow = 0; curRow < dt.Rows.Count; curRow++)
				{
					for (int curCol = 0; curCol < dt.Columns.Count; curCol++)
					{
						Console.Write(dt.Rows[curRow][curCol].ToString().Trim() + "\t");
					}
					Console.WriteLine();
				}
			}
		}

		//GETTING ROOMS ORDERED PERCENTAGE FROM TOTAL ROOMS **ONLY**
		private static void RoomPercentage(int id)
		{
			DBHelper h = new DBHelper(PROVIDER, SOURCE);
			string sql = "SELECT NumOfRooms, ((SELECT COUNT(*) FROM OrdersPerRoom) * 100 / NumOfRooms) WHERE " + id + " = Club.id FROM Club GROUP BY NumOfRooms";
			h.GetDataTable(sql);
		}
		public static bool ISBtNum(int num1, int min, int max)
        {
            for (int i = min; i < max; i++)
            {
                if (i == num1)
                {
                    return true;
                }
            }
            return false;
        }
		
		static void searchClubByRoomTypestateIDWeek(int typeOfRoom, int StateID, int WeekID)
        {
            DBHelper h = new DBHelper("P", "S");
            DataTable T = h.GetDataTable("SELECT Club.*, Room.Type, WeeksPerClub.WeekID" +
"FROM(Club INNER JOIN Room ON Club.id = Room.ClubID) INNER JOIN WeeksPerClub ON Club.id = WeeksPerClub.ClubID" +
"WHERE Room.Type =" + typeOfRoom + " AND Club.StateID =" + StateID + " AND[WeeksPerClub].[WeekID] =" + WeekID + " ;");
            int l = T.Rows.Count;
            if (l > 0)
            {
                for (int i = 0; i < l; i++)
                {
                    Console.WriteLine("Club ID- " + T.Rows[i]["id"]);
                    Console.WriteLine("Club Name- " + T.Rows[i]["name"]);
                    Console.WriteLine("Club state- " + T.Rows[i]["StateID"]);
                    Console.WriteLine("Club city- " + T.Rows[i]["city"]);
                    Console.WriteLine("Club street- " + T.Rows[i]["street"]);
                    Console.WriteLine("Club street number- " + T.Rows[i]["streetNum"]);
                    Console.WriteLine("Club category- " + T.Rows[i]["catagory"]);
                    Console.WriteLine("Club rating- " + T.Rows[i]["Rating"]);
                    Console.WriteLine("numbr of room in Club- " + T.Rows[i]["NumOfRoom"]);
                    Console.WriteLine("room type- " + T.Rows[i]["Type"]);
                    Console.WriteLine("week ID- " + T.Rows[i]["WeekID"]);
                }
            }

        }

        public static int IntInput(string s)
        {
            if (s == "" || s == null)
            {
                s = "your request was not valid please try again.";
            }
            int input = -1;
            bool flag = true;
            while(flag)
            {
                try
                {
                    input = int.Parse(Console.ReadLine());
                    flag = false;
                }
                catch(Exception) {
                    Console.WriteLine(s);
                }
            }
            return input;
        }

        public static string StringInput(string s)
        {
            if (s == "" || s == null)
            {
                s = "your request was not valid please try again.";
            }
            string input = "";
            bool flag = true;
            while (flag)
            {
                try
                {
                    input = Console.ReadLine();
                    flag = false;
                }
                catch (Exception)
                {
                    Console.WriteLine(s);
                }
            }
            return input;
        }

        public static double doubleInput(string s)
        {
            if (s == "" || s == null)
            {
                s = "your request was not valid please try again.";
            }
            double input = -1;
            bool flag = true;
            while (flag)
            {
                try
                {
                    input = double.Parse(Console.ReadLine());
                    flag = false;
                }
                catch (Exception)
                {
                    Console.WriteLine(s);
                }
            }
            return input;
        }        
        //public static bool Validinfo(int num)
        //{

        //}
    }
    //static void SearchClubByCountry(int country)
    //{
    //    string sql = ("SELECT * FROM Club WHERE StateID =" + country);
    //    try
    //    {
    //        //פתיחת חיבור לבסיס הנתונים
    //        string connString = String.Format(@"Provider={0};Data Source={1};Persist Security Info=False;", PROVIDER, SOURCE);
    //        OleDbConnection conn = new OleDbConnection(connString);
    //        conn.Open();

    //        //Create Command and Reader for the data

    //        OleDbCommand cmd = new OleDbCommand(sql, conn);
    //        OleDbDataReader rd = cmd.ExecuteReader();

    //        //Create an empty data table
    //        DataTable dataTable = new DataTable();
    //        if (rd != null)
    //        {
    //            //Populate the reader data into it
    //            dataTable.Load(rd);
    //            //Now connection can be closed and data is still in the data table!
    //            conn.Close();
    //        }

    //        //Print the data from the dataTable
    //        //Loop through rows (act just like an array)
    //        for (int i = 0; i < dataTable.Rows.Count; i++)
    //        {
    //            Console.WriteLine("Record number {0}", i);
    //            //Get the row object
    //            DataRow dr = dataTable.Rows[i];
    //            //Loop through the rows (alternatively, you can get the value of a column directy by its name, for example: dr["Address"]
    //            for (int j = 0; j < dataTable.Columns.Count; j++)
    //            {
    //                DataColumn dc = dataTable.Columns[j];
    //                Console.WriteLine("{0}: {1}", dc.ColumnName, dr[j]);
    //            }
    //        }
    //    }
    //    catch (Exception e)
    //    {
    //        throw new Exception("Unable to search Club", e);

    //    }
    //}
    //static void SearchClubByRoom(int roomType)
    //{
    //    string sql = ("SELECT Club.*, Room.Type FROM Club INNER JOIN Room ON Club.id = Room.ClubID WHERE Room.Type =" + roomType);
    //    try
    //    {
    //        //פתיחת חיבור לבסיס הנתונים
    //        string connString = String.Format(@"Provider={0};Data Source={1};Persist Security Info=False;", PROVIDER, SOURCE);
    //        OleDbConnection conn = new OleDbConnection(connString);
    //        conn.Open();

    //        //Create Command and Reader for the data

    //        OleDbCommand cmd = new OleDbCommand(sql, conn);
    //        OleDbDataReader rd = cmd.ExecuteReader();

    //        //Create an empty data table
    //        DataTable dataTable = new DataTable();
    //        if (rd != null)
    //        {
    //            //Populate the reader data into it
    //            dataTable.Load(rd);
    //            //Now connection can be closed and data is still in the data table!
    //            conn.Close();
    //        }

    //        //Print the data from the dataTable
    //        //Loop through rows (act just like an array)
    //        for (int i = 0; i < dataTable.Rows.Count; i++)
    //        {
    //            Console.WriteLine("Record number {0}", i);
    //            //Get the row object
    //            DataRow dr = dataTable.Rows[i];
    //            //Loop through the rows (alternatively, you can get the value of a column directy by its name, for example: dr["Address"]
    //            for (int j = 0; j < dataTable.Columns.Count; j++)
    //            {
    //                DataColumn dc = dataTable.Columns[j];
    //                Console.WriteLine("{0}: {1}", dc.ColumnName, dr[j]);
    //            }
    //        }
    //    }
    //    catch (Exception e)
    //    {
    //        throw new Exception("Unable to search Club", e);

    //    }
    //}
}
